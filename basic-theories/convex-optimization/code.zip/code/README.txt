Matlab, Python, and Julia data files for additional exercises for Boyd & Vandenberghe, Convex Optimization.
