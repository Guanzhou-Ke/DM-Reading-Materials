import numpy as np

# Ninit = np.matrix([1.0, 0.0, 0.0])
# c = np.matrix([2.5, 2.5, 2.5])
# R = 8.13
# V0 = 1.0
# T0 = 1000.0
# Vreact = 1.0
# Treact = 1000.0
# s0 = np.matrix([248.462, 243.507, 228.087])

Ninit = [1.0, 0.0, 0.0]
c = [2.5, 2.5, 2.5]
R = 8.13
V0 = 1.0
T0 = 1000.0
Vreact = 1.0
Treact = 1000.0
s0 = [248.462, 243.507, 228.087]
